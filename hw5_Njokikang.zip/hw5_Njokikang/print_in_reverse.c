#include <stdio.h>
#include <string.h>
// Name: Shania Njokikang

/*
 * This program reads a word from the user, reverses it, and prints the reversed word.
 * It then checks if the word is a palindrome by comparing the original and reversed strings.
 * If they match, it prints "palindrome"; otherwise, it prints "not palindrome."
 */
int main() {
    char word[21];  // 20 characters + 1 for the null terminator
    char reversed[21];
    int length, i;

    // Read the word from the user
    printf("Enter word: ");
    scanf("%20s", word);

    // Get the length of the word
    length = strlen(word);

    // Reverse the word
    for (i = 0; i < length; i++) {
        reversed[i] = word[length - i - 1];
    }
    reversed[length] = '\0';  // Null-terminate the reversed string

    // Print the reversed word
    printf("%s\n", reversed);

    // Check if it's a palindrome
    if (strcmp(word, reversed) == 0) {
        printf("palindrome\n");
    } else {
        printf("not palindrome\n");
    }

    return 0;
}
