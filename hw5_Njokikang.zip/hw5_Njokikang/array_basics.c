#include <stdio.h>

#define MAX_SIZE 20
// Name: Shania Njokikang
/*
 * This program performs various operations on an array, such as reading,
 * printing, replacing values, incrementing all elements, finding the minimum, and computing
 * the average. The user interacts with the program through a simple menu interface.
 */

int main() {
    int arr[MAX_SIZE], size = 0;
    char option;
    int index, value, increment;
    float sum;

    do {
        printf("\nr - read array\np - print array\ni - replace value at index\n");
        printf("v - increment all values\nm - find minimum value\n");
        printf("a - compute average\ne - exit\nEnter menu option: ");
        scanf(" %c", &option);

        switch (option) {
            case 'r':
                printf("Enter the array size: ");
                scanf("%d", &size);
                if (size > 0 && size <= MAX_SIZE) {
                    printf("Enter the array values: ");
                    for (int i = 0; i < size; i++) {
                        scanf("%d", &arr[i]);
                    }
                } else {
                    printf("Invalid size!\n");
                }
                break;

            case 'p':
                printf("The array is: ");
                for (int i = 0; i < size; i++) {
                    printf("%4d", arr[i]);
                }
                printf("\n");
                break;

            case 'i':
                printf("Enter index: ");
                scanf("%d", &index);
                printf("Enter value: ");
                scanf("%d", &value);
                if (index >= 0 && index < size) {
                    arr[index] = value;
                } else {
                    printf("Invalid index!\n");
                }
                break;

            case 'v':
                printf("Enter the value to increment: ");
                scanf("%d", &increment);
                for (int i = 0; i < size; i++) {
                    arr[i] += increment;
                }
                break;

            case 'm':
                if (size > 0) {
                    int min = arr[0];
                    for (int i = 1; i < size; i++) {
                        if (arr[i] < min) {
                            min = arr[i];
                        }
                    }
                    printf("The minimum value in the array is: %d\n", min);
                } else {
                    printf("Array is empty!\n");
                }
                break;

            case 'a':
                if (size > 0) {
                    sum = 0;
                    for (int i = 0; i < size; i++) {
                        sum += arr[i];
                    }
                    printf("The average is: %.2f\n", sum / size);
                } else {
                    printf("Array is empty!\n");
                }
                break;

            case 'e':
                printf("Bye\n");
                break;

            default:
                printf("Option not recognized.\n");
                break;
        }
    } while (option != 'e');

    return 0;
}
