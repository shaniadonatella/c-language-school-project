#include <stdio.h>
#include <string.h>
// Name: Shania Njokikang
/*
 * This program reads two strings from the user and compares them character by character.
 * If the strings have the same length and all characters match, it prints "EQUAL";
 * otherwise, it prints "NOT EQUAL." The comparison is case-sensitive.
 */

#define MAX_LENGTH 21  // 20 characters + 1 for the null terminator
int main() {
    char s1[MAX_LENGTH], s2[MAX_LENGTH];
    int length1, length2, count_bad = 0;

    // Read the two strings
    printf("Enter 1st word: ");
    scanf("%20s", s1);
    printf("Enter 2nd word: ");
    scanf("%20s", s2);

    // Get the lengths of both strings
    length1 = strlen(s1);
    length2 = strlen(s2);

    // Check if lengths are different
    if (length1 != length2) {
        printf("NOT EQUAL\n");
    } else {
        // Compare each character
        for (int k = 0; k < length1; k++) {
            if (s1[k] != s2[k]) {
                count_bad++;
                break;  // You can break early since we know they are not equal
            }
        }

        // Output result
        if (count_bad == 0) {
            printf("EQUAL\n");
        } else {
            printf("NOT EQUAL\n");
        }
    }

    return 0;
}
