#include <stdio.h>

#define MAX_SIZE 20
// Name: Shania Njokikang
int main() {
    int arr[MAX_SIZE], indexes[MAX_SIZE];
    int n, val, count = 0;

    // Step 1: Read the number of values in the array
    printf("How many values are in your array? ");
    scanf("%d", &n);

    // Step 2: Read the array values
    printf("Enter the array values (integers): ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Step 3: Print the array using cell width of 4
    for (int i = 0; i < n; i++) {
        printf("%4d", arr[i]);
    }
    printf("\n");

    // Step 4: Read the value to search for
    printf("What value do you want to search for? ");
    scanf("%d", &val);

    // Step 5: Search for val in arr and store indices in indexes
    for (int i = 0; i < n; i++) {
        if (arr[i] == val) {
            indexes[count] = i;
            count++;
        }
    }

    // Step 6: Print the results
    printf("%d was found %d times.\n", val, count);
    if (count > 0) {
        printf("The indexes where %d occurs are: ", val);
        for (int i = 0; i < count; i++) {
            printf("%d", indexes[i]);
            if (i < count - 1) {
                printf(", ");
            }
        }
        printf("\n");
    }
    printf("Bye\n");

    return 0;
}
