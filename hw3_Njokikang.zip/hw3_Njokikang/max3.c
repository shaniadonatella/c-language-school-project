#include <stdio.h>

// Name: Shania Njokikang
// Program Description: This program reads three integers from the user and determines
// which of the three is the maximum. It checks all possible cases to identify the max
// value, including when there are ties between two or all three numbers.

int main() {
    int num1, num2, num3; // Variables to store the three input integers

    // Prompt to enter three integers separated by spaces
    printf("Enter 3 integers separated by a space: ");
    scanf("%d %d %d", &num1, &num2, &num3); // Read the three integers

    // Determine the maximum value among num1, num2, and num3
    // Case 1: num1 is the max or tied with others as max
    if (num1 >= num2 && num1 >= num3) {
        printf("The max is: %d\n", num1);
    }
    // Case 2: num2 is the max or tied with num3 as max
    else if (num2 >= num1 && num2 >= num3) {
        printf("The max is: %d\n", num2);
    }
    // Case 3: num3 is the max
    else {
        printf("The max is: %d\n", num3);
    }

    return 0;
}
