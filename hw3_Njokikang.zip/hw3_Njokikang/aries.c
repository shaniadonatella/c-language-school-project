#include <stdio.h>

// Name: Shania Njokikang
// Program Description: This program reads the month and day from the user and checks whether
// someone born on that date falls under the Aries astrological sign.
// Aries dates range from March 21 to April 19.

int main() {
    int month, day; // Variables to store month and day

    // Print program description
    printf("This program reads the month and day from the user and checks whether\n");
    printf("someone born on that date falls under the Aries astrological sign.\n");
    printf("Aries dates range from March 21 to April 19.\n");

    // Prompt the to enter the month and read input
    printf("Enter the month: ");
    scanf("%d", &month);

    // Prompt to enter the day and read input
    printf("Enter the day: ");
    scanf("%d", &day);

    // Check if the date falls within the Aries range
    if ((month == 3 && day >= 21 && day <= 31) || (month == 4 && day >= 1 && day <= 19)) {
        printf("Aries\n"); // Print Aries if the date matches
    } else {
        printf("Not Aries\n"); // Print Not Aries if the date does not match
    }

    // Print farewell message
    printf("Bye\n");

    return 0; // End of program
}
