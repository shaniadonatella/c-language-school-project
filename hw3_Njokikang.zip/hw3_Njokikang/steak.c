#include <stdio.h>

// Name: Shania Njokikang
// Program Description: This program reads a temperature from the user and prints the corresponding
// steak doneness level based on the temperature ranges provided. The levels include "Rare",
// "Medium Rare", "Medium", "Medium Well", "Well", and "What have you done?!". Additionally,
// if the temperature is below 120, it prints "Start the fire!".

int main() {
    int temp; // Variable to store the temperature input

    // Prompt to enter the meat temperature
    printf("Enter the measured meat temperature: ");
    scanf("%d", &temp); // Read the temperature as an integer

    // Check temperature ranges and print the corresponding doneness level
    if (temp < 120) {
        printf("Start the fire!\n"); // Temperature is below 120
    } else if (temp >= 120 && temp < 130) {
        printf("Rare\n"); // Temperature is between 120 and 129
    } else if (temp >= 130 && temp < 135) {
        printf("Medium Rare\n"); // Temperature is between 130 and 134
    } else if (temp >= 135 && temp < 145) {
        printf("Medium\n"); // Temperature is between 135 and 144
    } else if (temp >= 145 && temp < 155) {
        printf("Medium Well\n"); // Temperature is between 145 and 154
    } else if (temp >= 155 && temp < 165) {
        printf("Well\n"); // Temperature is between 155 and 164
    } else {
        printf("What have you done?!\n"); // Temperature is 165 or higher
    }

    return 0; // End of the program
}
